﻿/*
 * This is a multi-lines, or delimited, comment.
 * CSCI 1301 lab: hello world
 */

using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to the lab portion of CSCI 1301!"); // This is an in-line comment.
    }
}
