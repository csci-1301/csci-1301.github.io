﻿using System;

class Program
{
    static void Main()
    {
        Rectangle test = new Rectangle();
    }
}
